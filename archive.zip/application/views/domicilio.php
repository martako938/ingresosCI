<div v-if="viewDomicilio">
    <div class="container ">
        <div class="alert alert-dismissible alert-secondary profundidad2" style="padding-top: 25px !important;">
            <h3 class="text-center" style="padding-bottom: 15px;">Registra/Actualiza tu domicilio.</h3>
            <form id="actualizaDomi" @submit.prevent="actualizarDomicilio()">
                   
                <div class="row g-3">
                    <div class="col-sm-6">
                        <label for="entidad">Entidad Federativa</label>
                        <select id="entidad" name="entidad" class="form-select text-uppercase" v-model="domicilio.vcNomLarEntFed">    
                            <option value="" disabled >Seleccionar...</option><template v-for="enti in entidadesAPI" :key="enti.tiCveEntFed"><option>{{enti.vcNomEntFed}}</option></template>
                        </select>
                    </div>
                    <div class="col-sm-6">
                        <label for="alcaldia">Alcaldía/Municipio</label>
                        <select id="alcaldia" name="alcaldia" class="form-select text-uppercase" v-model="domicilio.vcPobl">    
                            <option value="" disabled>Seleccionar...</option><template v-for="alca in alcaldiasAPI2" :key="alca.cCvePobl"><option>{{alca.vcPobl}}</option></template>
                        </select>
                    </div>
                </div>

                <div v-if="viewCodPost">                    <!-- v-if  Para agregar  CP y colonia si no aparece en lista  -->
                    <label for="colonia2">Colonia - Código Postal</label>   
                    <div class="row align-items-center" >
                        <div class="col-sm-6">
                            <select disabled id="colonia2" name="colonia2" class="form-select text-uppercase" v-model="domicilio.vcColCp">    
                                <option value="" >Seleccionar...</option>
                                <template v-for="(col, index) in coloniasAPI2" :key="col.index">
                                    <option>
                                        {{col.vcColCp}}
                                    </option>
                            </template>
                            </select>
                        </div>   

                        <div class="col-sm-6">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" @change="mostrarColoniaCpConcat()" id="checkColCP" name="checkColCP" v-model="vcheckCol">
                                <label class="form-check-label" for="checkColCP">Escribe el nombre de tu colonia y tu CP</label>
                            </div>
                        </div>
                        
                    </div>
                    
                    <div class="row g-3">
                        <div class="col-sm-4">
                            <label for="numext">Colonia</label>
                            <input type="text"  required class="form-control" id="nombreColonia" name="nombreColonia" placeholder="Colonia" v-model="colAPI">
                        </div>

                        <div class="col-sm-4">
                            <label for="numext">Código Postal </label>
                            <input type="text"  maxlength="5" required class="form-control" id="numeroCodigo" name="numeroCodigo" placeholder="Código Postal" v-model="posAPI">
                        </div>       
                    </div>
                </div>                                         <!-- fin v-if -->

                <div v-if="viewCodPostConcat">            <!-- v-if 2 En cas contrario depliega lista -->
                    <label for="colonia2">Colonia - Código Postal</label>
                    <div class="row align-items-center">
                        
                        <div class="col-sm-6">
                            <select id="colonia2" name="colonia2" class="form-select text-uppercase" v-model="domicilio.vcColCp">    
                                <option value="" disabled >Seleccionar...</option>
                                <template v-for="(col, index) in coloniasAPI2" :key="col.index">
                                    <option>
                                        {{col.vcColCp}}
                                    </option>
                            </template>
                            </select>
                        </div>
                        
                        <div class="col-sm-6">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" @change="mostrarColoniaCp()" id="checkColCP" name="checkColCP" v-model="vcheckCol">
                                <label class="form-check-label" for="checkColCP">Escribe el nombre de tu colonia y tu CP</label>
                            </div>
                        </div>

                        <input type="hidden"  required class="form-control" id="colonia" name="colonia" placeholder="Colonia" v-model="colAPI">
                        <input type="hidden" step="50" min="1" required class="form-control" id="zip" name="zip" placeholder="Código Postal" v-model="posAPI">
                    </div>
                </div>                                          <!-- fin v-if 2 -->

                <div class="row g-3">
                    <div class="col-4">
                        <label for="calle">Calle</label><input type="text" required class="form-control text-uppercase" id="calle" name="calle" placeholder="Calle" v-model="domicilio.vcDom" > 
                    </div>
                    <div class="col-4">
                        <label for="numext">Número Ext.</label>
                        <input type="number" pattern="\d+" step="1" min="1" name="numext" required class="form-control" id="numext" placeholder="Número Exterior" v-model="domicilio.iNumExt">
                    </div>
                    <div class="col-4">
                        <label for="numint">Número Int.</label><input type="number" pattern="\d+" step="1" min="1" name="numint" class="form-control" id="numint" placeholder="Número Interior" v-model="domicilio.iNumInt">
                    </div>                    
                </div>
                                            
                <div class="row g-3">
                    <div class="col-sm-6">
                        <label for="mail">Email</label><input type="email" required class="form-control" id="mail" name="mail" placeholder="Email" v-model="domicilio.vcEmail">
                    </div>
                    <div class="col-sm-6">
                        <label for="tel">Teléfono</label><input type="number" class="form-control" id="tel" name="tel" placeholder="Num. Telefónico" v-model="domicilio.vcTel">
                    </div>
                </div>

                </br>

                <div class="container text-center">
                    
                    <input type="hidden" name="iNumEmp" value="<?= $iNumEmp  ?>"/>
                    <div class="btn-group mb-3">
                        <button type="button" class="btn btn-outline-secondary" :disabled="botonRegresarDomi" @click="regresar()">Regresar</button>
                        <button type="button" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#modalReco" :disabled="botonContinuarDomi" @click="actualizarDomicilio()">Continuar</button>
                    </div>
                    
                </div>
            </form>
        </div>

        <table class="table">
            </tfoot>
                <tfoot v-if="validacion_campos_domicilio.out.foot" :class="validacion_campos_domicilio.out.color">
                <tr class="fs-">
                    <td colspan="6" class="text-center ">{{ validacion_campos_domicilio.out.mensaje }}</td>
                    
                </tr>
                
            </tfoot>
        </table>

        <tr>{{ traeAlcaldiasColoniasCpAPIS2.out.mensaje2 }}</tr>

    </div>


    <!-- Modal Recordatorio -->
        <div class="modal fade" id="modalReco" tabindex="-1" aria-labelledby="modalReco" aria-hidden="false">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="RecoModalLabel">Registro de información para SVIDA</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="align-middle">
                                <!-- <embed :src="urlPdf + '#&navpanes=0&scrollbar=0'" type="application/PDF" width="100%" height="700px" /> -->
                                <p>Le recordamos que para concluir el trámite deberá descargar el formato, imprimir, firmar los formatos y posteriormente deberá entregar los documentos físicos a la Dirección de Sistemas de la Dirección General de Personal.</p>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-success" data-bs-dismiss="modal">Ok</button>
                        </div>
                    </div>
            </div>
        </div>




</div>

