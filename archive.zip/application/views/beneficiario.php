
<div v-if="viewInicio">  
    <div class="alert alert-dismissible alert-secondary profundidad2">
        <p>Nos permitimos hacer de su conocimiento, que la nueva plaza que ocupa cuenta con el beneficio del 
        Seguro de Vida Institucional para la Administración Pública Federal, con una cobertura equivalente a 40 
        veces la percepción ordinaria bruta mensual ante la SHCP.
            <br>En caso de aceptar esta prestación, deberá proporcionar la información que le solicitamos en esta aplicación, 
            descargar, imprimir y firmar los formatos, posteriormente entregar los documentos físicos 
            a la <a href="#" data-bs-toggle="modal" data-bs-target="#modalMap" ><u>Dirección de Sistemas de la Dirección General de Personal</u></a>
            <br><br>
            Nivel tabular: {{categorias.vcCveNivelTabShcp}}
            <br>Percepción ordinaria bruta mensual: {{categorias.mPerBruta}}
        </p>
    </div>
    
    <form id="actualizaBenefi" @submit.prevent="actualizarBeneficiarios()">
        <table class="table profundidad2">
            <thead class="text-center">
                <tr>
                    <th>#</th>
                    <th>Apellido Paterno</th>
                    <th>Apellido Materno</th>
                    <th>Nombre(s)</th>
                    <th>Porcentaje</th>
                    <th>Parentesco</th>
                </tr>
            </thead>
            
            <tbody class="text-center">          
                <template v-for="(bene, index) in beneficiarios" :key="index">     
                    <tr>
                        <td><input type="hidden" :id="'ser'+bene.siSerialBen" :name="'ser'+bene.siSerialBen" class="form-control text-uppercase" v-model="beneficiarios[index].siSerialBen">
                            {{index+1}}</td>
                        <td><input type="text" :id="'pat'+bene.siSerialBen" :name="'pat'+bene.siSerialBen" class="form-control text-uppercase" v-model="beneficiarios[index].vcPaternoBen"></td>
                        <td><input type="text" :id="'mat'+bene.siSerialBen" :name="'mat'+bene.siSerialBen" class="form-control text-uppercase" v-model="beneficiarios[index].vcMaternoBen"></td>
                        <td><input type="text" :id="'nom'+bene.siSerialBen" :name="'nom'+bene.siSerialBen" class="form-control text-uppercase" v-model="beneficiarios[index].vcNombreBen"></td>
                        <td><input type="number" max="100" min="0" :id=" 'por'+bene.siSerialBen" :name="'por'+bene.siSerialBen" class="form-control text-uppercase" v-model="beneficiarios[index].iPorcentaje"></td>      
                        <td>
                            <select :id="'par'+bene.siSerialBen" :name="'par'+bene.siSerialBen" class="form-select text-uppercase" v-model="beneficiarios[index].vcParent" >
                                <option value="0"></option>
                                <option v-for="parent in parentescos" :key="parent.siSec" :value="parent.vcParent" > 
                                    {{parent.vcParent}} 
                                </option>  
                            </select>
                        </td> 
                    </tr>
                </template>
            </tbody>
            <tfoot v-if="validacion_campos.salida.foot" :class="validacion_campos.salida.color">
            <tr class="fs-">
                <td colspan="6" class="text-center ">{{ validacion_campos.salida.mensaje }}</td>
            </tr>
            </tfoot>
        </table> 
            
        <div class="container text-center">
            <input type="hidden" name="iNumEmp" value="<?= $iNumEmp  ?>"/>
            <button type="button" class="btn btn-outline-success" :disabled="botonContinuar" @click="actualizarBeneficiarios()">Continuar</button>
        </div>
    </form>  

    <!-- Modal Map-->
    <div class="modal fade" id="modalMap" tabindex="-1" aria-labelledby="modalMap" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="mapModalLabel">UNAM Coordinación General de Planeación y Simplificación de la Gestión Institucional</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body">

                            <div class="form-group">                             
                                <div class="mapouter">
                                    <div class="gmap_canvas">
                                        <iframe src="https://maps.google.com/maps?q=Cto.%20Centro%20Cultural%2020,%20Insurgentes%20Cuicuilco,%20Coyoac%C3%A1n,%2004510%20Ciudad%20de%20M%C3%A9xico,%20CDMX&amp;t=&amp;z=17&amp;ie=UTF8&amp;iwloc=&amp;output=embed" width="765" height="650" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
                                        </iframe>
                                    </div>
                                </div>
                            </div>    

                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-success" data-bs-dismiss="modal">Cerrar</button>
                        </div>
                    </div>
            </div>
        </div>
</div>



