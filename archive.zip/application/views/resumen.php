<div v-if="viewResumen">

    <div class="text-end">
        <h3><strong>DESCARGUE FORMATOS</strong> <a href="#" data-bs-toggle="modal" data-bs-target="#modalDocto" ><i class="far fa-file-pdf fa-lg" style="color: red"></i></a></h3>
    </div>

    <div class="container">
        <div class="alert alert-dismissible alert-secondary profundidad2" style="padding-top: 25px !important; padding-bottom: 25px !important;">
            
            <h3 class="text-center" style="padding-bottom:15px;">Beneficiarios registrados</h4>
            <table class="table table-secondary">
                <thead class="text-center">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Apellido Paterno</th>
                        <th scope="col">Apellido Materno</th>
                        <th scope="col">Nombre(s)</th>
                        <th scope="col">Porcentaje</th>
                        <th scope="col">Parentesco</th>
                    </tr>
                </thead>
                <tbody class="text-center">
                    <template v-for="(bene, index) in beneficiarios" :key="index"> 
                        <tr v-if="beneficiarios[index].vcParent != 0">
                            <th  scope="row">{{beneficiarios[index].siSerialBen}}</th>
                            <td  style="text-transform:uppercase">{{beneficiarios[index].vcPaternoBen}}</td>
                            <td  style="text-transform:uppercase">{{beneficiarios[index].vcMaternoBen}}</td>
                            <td  style="text-transform:uppercase">{{beneficiarios[index].vcNombreBen}}</td>
                            <td >{{beneficiarios[index].iPorcentaje}}</td>
                            <td >{{beneficiarios[index].vcParent}}</td>
                        </tr>
                    </template>                   
                </tbody>
            </table>

            <div class="container">
                <h3 class="text-center" style="padding-bottom: 10px;">Domicilio registrado</h3>
                <div class="alert alert-dismissible alert-secondary" style="padding-top: 10px !important;">

                    <table class="table table-borderless">
                        <tbody class="text">          
                            <tr>
                                <th scope="row">Calle:</th>
                                <td>{{domicilio.vcDom}}</td>

                                <th scope="row">Número Ext.:</th>
                                <td>{{domicilio.iNumExt}}</td>

                                <th scope="row">Número Int.:</th>
                                <td>{{domicilio.iNumInt}}</td>
                            </tr>
                            <tr>
                                <th scope="row">Colonia:</th>
                                <td>{{colAPI}}</td>

                                <th scope="row">Código Postal:</th>
                                <td>{{posAPI}}</td>
                            </tr>
                            <tr>
                                <th scope="row">Entidad Federativa:</th>
                                <td >{{domicilio.vcNomLarEntFed}}</td>
                                <th scope="row">Alcaldía/Municipio:</th>
                                <td>{{domicilio.vcPobl}}</td>
                            </tr>
                            <tr>
                                <th scope="row">Email:</th>
                                <td >{{domicilio.vcEmail}}</td>
                                <th scope="row">Teléfono:</th>
                                <td>{{domicilio.vcTel}}</td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>   
            
            <div class="container text-center">
                <button type="button" class="btn btn-outline-secondary" :disabled="botonRegresarDomi" @click="regresar()">Regresar a beneficiarios</button>
            </div>
        </div>

        <!-- Modal PDF B5-->
        <div class="modal fade" id="modalDocto" tabindex="-1" aria-labelledby="modalDocto" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="pdfModalLabel">Formato SVI</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="align-middle">
                                <embed :src="urlPdf + '#&navpanes=0&scrollbar=0'" type="application/PDF" width="100%" height="700px" />
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cerrar</button>
                        </div>
                    </div>
            </div>
        </div>
        
    </div>
</div>