            <!-- End Content -->
            </div>
    </body>

</html>
<?php $hoy=date('d-m-Y'); $anio = substr($hoy,-4); //Anio  ?>
</br>
<div class="text-center"><em>&copy; UNAM Gastos Médicos DGP <?= $anio ?></em></div>
</br>
