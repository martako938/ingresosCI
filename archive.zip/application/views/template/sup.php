

<div id="content">
        <!-- <nav class="navbar navbar-dark bg-primary navSup"> -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark navSup">
            <div class="container">
                <div class="navbar-header navbar-left">
                    <a href="https://www.unam.mx/" class="hidden-xs navbar-brand"><img alt="UNAM" style="width: 95px" src="<?= base_url('/images/logoUNAM2.png')?>"></a>   
                </div>
                <div class="navbar-header navbar-center logo text-center">
                    <span class="titulo">Gastos Médicos Mayores</span><br>
                    
                </div>
                <div class="navbar-header navbar-right">
                    <a href="https://www.personal.unam.mx" class="hidden-xs navbar-brand"><img alt="DGPe" style="width: 90px"  src="<?= base_url('/images/LogotipoDGPE_blanco.png')?>"></a>   
                </div>
            </div>
        </nav>

        
        <!-- <nav class="navbar navbar-expand-md navbar-light bg-light navDelgada2"> -->
        <nav class="navbar navbar-expand-md navbar-light bg-light navDelgada2 profundidad2">
            <a class="navbar-brand titulo6" title="" href="<?= base_url('/elecciones')?>"> &nbsp;  </a>                         
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarColor01">
                <ul class="navbar-nav mr-auto ">
                    <!-- <li class="nav-item">
                        <a class="nav-link titulo5" href="<?= base_url('/calendario')?>" >&nbsp;&nbsp;&nbsp;Calendario </a>  
                    </li>
                    <li class="nav-item">
                        <a class="nav-link titulo5" href="#" data-bs-toggle="modal" data-bs-target="#modalDocto">&nbsp;&nbsp;&nbsp;Guía </a> 
                    </li> -->
                    <li class="nav-item"> 
                        <a class="nav-link titulo5" href="<?= base_url('/contacto')?>" >&nbsp;&nbsp;&nbsp;Contacto </a>  
                    </li>

                </ul>
                <form class="position-absolute top-50 end-0 translate-middle-y">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item">
                            <a class="nav-link titulo5" href="https://casiopea.personalds.unam.mx/sa/UI/Logout">&nbsp;&nbsp;&nbsp;Cerrar Sesión</a>
                        </li>
                    </ul>
                </form>
            </div>
        </nav>

</div>

<!-- Modal PDF de la Guía-->
<div class="modal fade" id="modalDocto" tabindex="-1" aria-labelledby="modalDocto" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
                <div class="modal-header navSup titulo3">
                    <h1 class="modal-title fs-5" id="pdfModalLabel">Guía rápida</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="align-middle">
                        <embed src="<?= base_url('/acerca/guia.pdf')?>" type="application/PDF" width="100%" height="700px" />
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn butBlue sizeWidth2" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
    </div>
</div>

<body class="conFondo">
    <div class="container">
        </br>
        <!-- Content -->