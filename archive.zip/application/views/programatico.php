<div id="appPrograma" > 

<div class="row">
        <div class="col-1"></div>
        <div class="col-4"><h4>Modulo: Cálculo Código Programático</h4></div>
        <div class="col-7"></div>
    </div>
    <br>

    <div class="container mt3 area4 profundidad">
        <br>
        <div class="row">
            <div class="col-6 text-center">
                <div class="card mb-2 profundidad2">
                    <div class="card-body edge2">
                                           
                            <h5> <b>Ingresa números de empleado:</b></h5>                            
                            <br>
                            <p class="card-text">
                                <!-- <input type="text" maxlength="7" id="iNumEmp"  name="iNumEmp" class="form-control form-control-sm edge2" v-model="busqueda" @keyup="procesarBusqueda" placeholder="Num. Trabajador"> 
                                 -->
                                
                                <textarea id="w3review" name="w3review" rows="4" cols="50">
                               
                                </textarea>

                            </p>
                            <!-- <button type="button" class="btn butGreen2 btn-sm"  @click="buscarRegistro" href="#"><i class="bi bi-search"></i></button> -->
                    </div>
                </div>

            </div>
            
            <div class="col-3 text-center">
               
               
            </div>
            
            

        </div>
        <br>
    </div>
    
</div>              <!-- Fin appPrograma -->