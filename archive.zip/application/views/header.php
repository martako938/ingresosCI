<html>
        <head>
                <title>CodeIgniter Tutorial</title>
        </head>
        <body>

                <h1><?php echo $title; ?></h1>

                <em>&copy; 2023</em>
        </body>
</html>                