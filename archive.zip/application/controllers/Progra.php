<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Progra extends CI_Controller {

    public function __construct(){
		parent::__construct();
		$this->load->model('Index_Model');
		$this->load->model('Progra_Model');
	}

	public function index(){
	
        $this->load->view('template/head');
		$this->load->view('template/sup');				
		$this->load->view('programatico');									//Lleva num de empleado
		$this->load->view('indxJS/pro' );
        $this->load->view('template/foot');	
    }
	
}