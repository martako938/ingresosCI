<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Beneficiario extends CI_Controller {
    
    public function __construct(){
		parent::__construct();
		$this->load->model('Beneficiario_Model');
        $this->load->model('Categoria_Model');
        $this->load->model('Domicilio_Model');
	}

    public function index(){

        $data['iNumEmp'] = $this->config->item('HTTP_NUMEMP');

        $this->load->view('template/head');
		$this->load->view('template/sup');

        $this->load->view('beneficiario',$data);
        $this->load->view('domicilio');
        $this->load->view('resumen');
		
        $this->load->view('template/foot');	

    }

    public function traeBene($iNumEmp){
		 $datos = $this->Beneficiario_Model->seleccionar_todo($iNumEmp); //Aqui se almacena lo encontrado en la tabla bd
		  echo json_encode($datos);
	}
    public function traeCatego($iNumEmp){
		 $datos = $this->Categoria_Model->seleccionar_categoria($iNumEmp); 
		  echo json_encode($datos);
	}
    public function traeDomi($iNumEmp){
        $datos = $this->Domicilio_Model->seleccionar_domicilio($iNumEmp); 	
		  echo json_encode($datos);
    }
    public function traeEnti(){
        $datos = $this->Domicilio_Model->seleccionar_entidad(0); 		
		  echo json_encode($datos);
    }
    public function traeParent(){
        $datos = $this->Beneficiario_Model->seleccionar_parentesco(); 		
		  echo json_encode($datos);
    }
    public function actuaBenefi(){
        $iNumEmp = ''; $i=0; $j=0;   $k=0;   $l=0;   $m=0;  // Contadores que llenara cada campo de un beneficiario $i $j $k $l $m
        foreach ($_POST as $campo => $valor) { 
            $var = "$".$campo."='". $valor."';"; eval($var); 
            if($valor === '0' || $valor === 0){  $valor = ''; }
            if($i<6){                                       //$ben Contador para hacer 5 beneficiarios en un arreglo
                $ben=1; $benef[$ben][$i] = $valor;
            }elseif($i>=6 && $i<12){
                $ben=2; $benef[$ben][$j] = $valor;
                $j++;
            }elseif($i>=12 && $i<18){
                $ben=3; $benef[$ben][$k] = $valor;
                $k++;
            }elseif($i>=18 && $i<24){
                $ben=4; $benef[$ben][$l] = $valor;
                $l++;
            }elseif($i>=24 && $i<30){
                $ben=5; $benef[$ben][$m] = $valor;
                $m++;
            } $i++;
        }
        $cont_ser=0;
        for($i=1; $i<=5; $i++){
            if($benef[$i][1] !=''){
                $cont_ser++; //Contador para reasignar SiSerialBen
            }
		    $this->Beneficiario_Model->actualizar_beneficiario($iNumEmp, $benef[$i][0], $benef[$i][1], $benef[$i][2], $benef[$i][3], $benef[$i][5], $benef[$i][4], $cont_ser);
        }
    }
    public function actuaDomi(){
        $iNumEmp = ''; $calle = ''; $numext = ''; $numint = '';$entidad = ''; $colonia = '';  $zip = '';  $alcaldia = ''; $mail = ''; $tel = ''; $colonia2 = ''; $nombreColonia = '';  $numeroCodigo = '';
        foreach ($_POST as $campo => $valor) {
            $var = "$".$campo."='". $valor."';"; 
            eval($var); 
        }

        $this->Domicilio_Model->actualizar_domicilio($iNumEmp, $calle, $numext, $numint, $entidad, $colonia, $zip, $alcaldia, $mail, $tel ,$colonia2, $nombreColonia ,$numeroCodigo);
    
    }
    public function creaPdf($iNumEmp){

        function cifrar_descrifrar($action, $num_emp) {
            $output = false;
            $encrypt_method = "AES-256-CBC";
            $secret_key = 'This is my secret key';
            $secret_iv = 'This is my secret iv';
            // hash
            $key = hash('sha256', $secret_key);
            // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
            $iv = substr(hash('sha256', $secret_iv), 0, 16);
            if( $action == 'encrypt' ) {
                $output = openssl_encrypt($num_emp, $encrypt_method, $key, 0, $iv);
                $output = base64_encode($output);
            }
            else if( $action == 'decrypt' ){
                $output = openssl_decrypt(base64_decode($num_emp), $encrypt_method, $key, 0, $iv);
            }
            return $output;        
        }//Fin de function cifrar($password)

        $serv = "https://torvi.personalds.unam.mx:9243/descargaPDF/ssiPdf/svida.php?id=";
        $cadena = cifrar_descrifrar("encrypt", $iNumEmp);
        $urlpdf = $serv.$cadena;
        echo json_encode($urlpdf);
        //return $urlpdf;
    }

    
   



}