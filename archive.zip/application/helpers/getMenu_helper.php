<?php
function main menu(){
    return array(
        array(
            'title' => 'login',
             'url' = base_url(),
        ),
        array(
            'title' => 'Registro',
             'url' = base_url('index.php/registro'),
        )
    )
}