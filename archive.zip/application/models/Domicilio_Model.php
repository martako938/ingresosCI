<?php
class Domicilio_Model extends CI_Model{

    public function seleccionar_domicilio($iNumEmp){
        $this-> dbdomicilios = $this->load->database('ms_dbSeguroSepInd', TRUE);
        $sql="  SELECT vcDom, vcCol, vcPobl, cCveCodPos, tiCveEntFed, vcNomLarEntFed, vcTel, iNumExt, iNumInt, vcEmail, vcColCp 
                FROM tDomEmpSSI 
                WHERE iNumEmp = $iNumEmp;";

        $query = $this->dbdomicilios->query($sql, array(intval($iNumEmp)));
        $this->dbdomicilios->close();

        $domicilioOut = array();
        foreach ( $query->result_array() as $row )
        {
            $domicilioOut = array( 
                'vcDom' =>  $row['vcDom'],
                'vcCol' => utf8_encode($row['vcCol']),
                'vcPobl'  => utf8_encode($row['vcPobl']),
                'cCveCodPos'  => $row['cCveCodPos'],
                'tiCveEntFed'  => $row['tiCveEntFed'],
                'vcNomLarEntFed'  => utf8_encode($row['vcNomLarEntFed']),
                'vcTel'  => $row['vcTel'],   
                'iNumExt'  => $row['iNumExt'],   
                'iNumInt'  => $row['iNumInt'],   
                'vcEmail'  => $row['vcEmail'],
                'vcColCp' => utf8_encode($row['vcColCp'])
            );
         }
        return $domicilioOut;
    }
    public function seleccionar_entidad($val){
        $this-> dbentidades = $this->load->database('ms_dbSeguroSepInd', TRUE);
        if($val === 0){
            $sql="SELECT tiCveEntFed, vcNomLarEntFed FROM dbo_CENTFEDS WHERE tiCveEntFed NOT IN (0,33,35);";
         }else{
            $sql = "SELECT tiCveEntFed FROM dbo_CENTFEDS WHERE vcNomLarEntFed='$val';";
         }
        $query = $this->dbentidades->query($sql, array());
        $this->dbentidades->close();

        $entidadOut = array();
        foreach ( $query->result_array() as $row )
        {
            $entidadOut[] = array( 
                'tiCveEntFed' =>  $row['tiCveEntFed'],
                'vcNomLarEntFed' => $row['vcNomLarEntFed']  
            );
         }
        return $entidadOut;
    }


    public function actualizar_domicilio( $iNumEmp, $vcDom, $iNumExt, $iNumInt, $vcNomLarEntFed, $vcCol, $cCveCodPos, $vcPobl, $vcEmail, $vcTel, $vcColCp, $nomcol, $numcod){  //Funcion para actualizar domicilio  

        $this-> dbentidad = $this->load->database('ms_dbSeguroSepInd', TRUE);
        $sql_entidad = "SELECT tiCveEntFed FROM dbo_CENTFEDS WHERE vcNomLarEntFed='$vcNomLarEntFed';";
        $query_entidad = $this->dbentidad->query($sql_entidad, array($vcNomLarEntFed)); 
        $this->dbentidad->close();
        $tiCveEntFed = 0;
        foreach ( $query_entidad->result_array() as $row )
        {  $tiCveEntFed =  (int)$row['tiCveEntFed'] ;  }

        $vcDom = strtoupper($vcDom);
        $vcNomLarEntFed = strtoupper($vcNomLarEntFed);
        $vcCol= utf8_decode(strtoupper($vcCol));
        $vcPobl= strtoupper($vcPobl);
        $vcColCp= utf8_decode(strtoupper($vcColCp)); //Nuevo campo

        if( $nomcol != '' &&  $numcod != ''){  //Para sustitiur por entrada manual de colonia, CP  y solonia - CP
            $colCod = $nomcol.' - '.$numcod;
            $this-> dbdomicilios = $this->load->database('ms_dbSeguroSepInd', TRUE);
            $sql="  UPDATE tDomEmpSSI 
                    SET vcDom=?, iNumExt=?, iNumInt=?, tiCveEntFed =?, vcNomLarEntFed=?, vcCol=?, cCveCodPos=?, vcPobl=?, vcEmail=?, vcTel=?, vcColCp=?
                    WHERE iNumEmp=$iNumEmp";
            $query = $this->dbdomicilios->query($sql, array($vcDom, $iNumExt, $iNumInt, $tiCveEntFed, $vcNomLarEntFed, $nomcol, $numcod, $vcPobl, $vcEmail, $vcTel, $colCod )); 
        }else{
            $this-> dbdomicilios = $this->load->database('ms_dbSeguroSepInd', TRUE);
            $existSql= "SELECT  iNumEmp FROM tDomEmpSSI WHERE iNumEmp = $iNumEmp;";
            $queryExist = $this->dbdomicilios->query($existSql, $iNumEmp);

            $salida = '';
            foreach ( $queryExist->result_array() as $row ){
                $salida = $row['iNumEmp'];
            }
            $tamanio = strlen($salida);
            if($tamanio != 0 ){
                $sql=" UPDATE tDomEmpSSI 
                    SET vcDom=?, iNumExt=?, iNumInt=?, tiCveEntFed =?, vcNomLarEntFed=?, vcCol=?, cCveCodPos=?, vcPobl=?, vcEmail=?, vcTel=?, vcColCp=?
                    WHERE iNumEmp=$iNumEmp ";   
                $query = $this->dbdomicilios->query($sql, array($vcDom, $iNumExt, $iNumInt, $tiCveEntFed, $vcNomLarEntFed, $vcCol, $cCveCodPos, $vcPobl, $vcEmail, $vcTel, $vcColCp )); //UPDATE
            }else{
                $vcRfcReg = '';
                $sql=" INSERT INTO tDomEmpSSI 
                        (iNumEmp, vcDom, vcCol, vcPobl, cCveCodPos, tiCveEntFed, vcNomLarEntFed, vcTel, vcRfcReg, iNumExt, iNumInt, vcEmail, sdFecReg, iNumEmpReg)
                        VALUES(?,?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, getdate(), ?); ";   
                $query = $this->dbdomicilios->query($sql, array($iNumEmp, $vcDom, $vcCol, $vcPobl, $cCveCodPos, $tiCveEntFed, $vcNomLarEntFed, $vcTel, $vcRfcReg, $iNumExt, $iNumInt, $vcEmail,  $iNumEmp )); //INSERT
            }
        }

        $this->dbdomicilios->close();

        if($query === true){
            return ("OK");
        }
        else{
            return ("NO");
        }


    }


}

