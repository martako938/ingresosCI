<?php
class Index_Model extends CI_Model{


}