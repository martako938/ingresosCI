<?php
class Progra_Model extends Index_Model{



}