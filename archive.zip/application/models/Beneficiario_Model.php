<?php
class Beneficiario_Model extends CI_Model{

    public function seleccionar_todo($iNumEmp){ 
        $this-> dbbeneficiarios = $this->load->database('ms_dbSeguroSepInd', TRUE);
        $sql="  SELECT iNumEmp, siSerialBen, vcPaternoBen, vcMaternoBen, vcNombreBen, vcParent, iPorcentaje 
                FROM tBeneficiarioSVI 
                WHERE iNumEmp=? 
                ORDER BY siSerialBen;";
        $query = $this->dbbeneficiarios->query($sql, array(intval($iNumEmp)));
        $this->dbbeneficiarios->close();

        $salida = array();
        foreach ( $query->result_array() as $row )
        {
            $salida[] = array(
                'iNumEmp' =>  $row['iNumEmp'],
                'siSerialBen' => (int)$row['siSerialBen'],
                'vcPaternoBen'  => strtoupper(utf8_encode($row['vcPaternoBen'])) ,
                'vcMaternoBen' => utf8_encode($row['vcMaternoBen']),
                'vcNombreBen'  => utf8_encode($row['vcNombreBen']),
                'vcParent'  => utf8_encode($row['vcParent']),
                'iPorcentaje'  => (int)$row['iPorcentaje']           
            );
         }
        $tamanio = count($salida);
        for($i = $tamanio; $i < 5; $i++){
            $salida[]= array(
                'iNumEmp' =>  "",
                'siSerialBen' => $i+1,
                'vcPaternoBen'  => "" ,
                'vcMaternoBen' => "",
                'vcNombreBen'  => "",
                'vcParent'  => 0,
                'iPorcentaje'  => ""   
            );
        }
        return $salida;
    } 
    public function actualizar_beneficiario( $iNumEmp, $ser, $pat, $mat, $nom, $par, $por, $cont_ser){
        $pat = strtoupper($pat);
        $mat = strtoupper($mat);
        $nom = strtoupper($nom);
        $par = strtoupper($par);
        $vcNom1 = strtoupper($pat." ".$mat." ".$nom);
        $vcNom2 = strtoupper($nom." ".$pat." ".$mat); 
        $iNumEmp = intval($iNumEmp); 
        $ser = intval($ser);
        
        if( $pat === '' && $mat === '' && $nom === ''  ){
            $this-> dbbeneficiarios = $this->load->database('ms_dbSeguroSepInd', TRUE);
            $sql="DELETE FROM tBeneficiarioSVI 
                    WHERE iNumEmp=$iNumEmp 
                    AND siSerialBen=$ser";
            $query = $this->dbbeneficiarios->query($sql, array($pat,$mat,$nom,$por,$par,$vcNom1,$vcNom2));
            $this->dbbeneficiarios->close();
        }else{
            //Busca si existe ya el beneficiario
            $this-> dbbeneficiarios = $this->load->database('ms_dbSeguroSepInd', TRUE);
            $sql="  SELECT iNumEmp, siSerialBen, vcPaternoBen 
                    FROM tBeneficiarioSVI 
                    WHERE iNumEmp=$iNumEmp 
                    AND siSerialBen=$ser;";
            $query = $this->dbbeneficiarios->query($sql, array($iNumEmp,$ser));
            $this->dbbeneficiarios->close();
            foreach ( $query->result_array() as $row ){ 
                $out = (int)$row['siSerialBen']; 
            }
            if($out){ //Si ya existe el beneficiario solo actualiza
                $this-> dbbeneficiarios = $this->load->database('ms_dbSeguroSepInd', TRUE);
                $sql=" UPDATE tBeneficiarioSVI 
                        SET vcPaternoBen=? , vcMaternoBen=?, vcNombreBen=?, iPorcentaje=? , vcParent=? ,vcNomBen1=? ,vcNomBen2=? ,siSerialBen=? 
                        WHERE iNumEmp=$iNumEmp 
                        AND siSerialBen=$ser";
                $query = $this->dbbeneficiarios->query($sql, array($pat,$mat,$nom,$por,$par,$vcNom1,$vcNom2,$cont_ser ));
                $this->dbbeneficiarios->close();
            }
            else{ 
                //Si no existe el beneficiario hace insert
                $this-> dbbeneficiarios = $this->load->database('ms_dbSeguroSepInd', TRUE);
                $sql= "INSERT INTO tBeneficiarioSVI (iNumEmp, siSerialBen, vcNomBen1, vcNomBen2, vcPaternoBen, vcMaternoBen, vcNombreBen, vcParent, iPorcentaje ) 
                                            VALUES ($iNumEmp, $cont_ser, '$vcNom1', '$vcNom2', '$pat', '$mat','$nom', '$par', $por );";       

                $query = $this->dbbeneficiarios->query($sql, array($iNumEmp, $cont_ser, $vcNom1, $vcNom2, $pat, $mat, $nom, $par, $por ));
                $this->dbbeneficiarios->close();
            }
        }
        if($query === true){
            return ("OK");
        }
        else{
            return ("NO");
        }
    }
    public function seleccionar_parentesco(){
        $this-> dbparentescos = $this->load->database('ms_dbSeguroSepInd', TRUE);
        $sql="SELECT siSec, vcParent FROM cParentesco;";

        $query = $this->dbparentescos->query($sql, array());
        $this->dbparentescos->close();

        $parentescoOut = array();
        foreach ( $query->result_array() as $row )
        {
            $parentescoOut[] = array( 
                'siSec' =>  $row['siSec'],
                'vcParent' => utf8_encode($row['vcParent'])  
            );
         }
        return $parentescoOut;
    }

        
}

?>