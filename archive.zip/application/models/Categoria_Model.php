<?php
class Categoria_Model extends CI_Model{

    public function seleccionar_categoria($iNumEmp){

        function FormatoPesos($cantidad){
            $posicion_punto = strpos($cantidad, '.');         
            if($posicion_punto != false){
                $cantidad = substr($cantidad, 0, $posicion_punto + 5); 
            }//Fin de if($posicion_punto == false){     
            $cantidad = round($cantidad, 2);
            $cantidad = number_format($cantidad, 2);  
            $cantidad = "$".$cantidad;    
            return $cantidad;
        }

        $this-> dbcategorias = $this->load->database('ms_dbSeguroSepInd', TRUE);
        $sql="  SELECT c.mPerBruta, c.vcCveNivelTabShcp, c.vcCategShcp
                FROM cCategShcp c, tContPropuesta p
                WHERE p.iNumEmp = $iNumEmp
                AND c.vcAnexo = p.vcAnexo;";
               
        setlocale(LC_MONETARY, 'en_US.UTF-8'); 
        $query = $this->dbcategorias->query($sql, array(intval($iNumEmp)));
        $this->dbcategorias->close();

        $categoriaOut = array();

        foreach ( $query->result_array() as $row )
        {
            $categoriaOut = array( 
                'mPerBruta' =>  FormatoPesos($row['mPerBruta']),
                'vcCveNivelTabShcp' => $row['vcCveNivelTabShcp'],
                'vcCategShcp'  => $row['vcCategShcp']   
            );
         }
        return $categoriaOut;

    }
    

}