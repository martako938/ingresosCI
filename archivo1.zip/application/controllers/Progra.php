<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Progra extends CI_Controller {

    public function __construct(){
		parent::__construct();
		$this->load->model('Index_Model');
		$this->load->model('Progra_Model');
		$this->load->model('Usuario');
	}

	public function index(){
		$datos['usuarios'] = $this->Usuario->seleccionar_todo();
	
        $this->load->view('template/head');
		$this->load->view('template/sup');				
		$this->load->view('programatico', $datos);	
		$this->load->view('indxJS/pro' );
        $this->load->view('template/foot');

    }

	public function traeSal(){
		$datos = $this->Progra_Model->seleccionar_salida(); 
		 echo json_encode($datos);
   	}

	public function ingresaNum(){
		$vcNums = '';
		foreach ($_POST as $campo => $valor) {
            $var = "$".$campo."='". $valor."';"; 
            eval($var); 
        }
	
		//$datosL = $vcNums;	

		$datos= array(
			"vcNums" => $vcNums,
			"POST" =>  $_POST
		);


		echo json_encode($datos);
	}
	
}