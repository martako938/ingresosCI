<?php 
class Usuario extends CI_Model {
    public function seleccionar_todo() {
        $this->db->select('*');
        $this->db->from('usuarios');
        return $this->db->get()->result();
    }
}

?>