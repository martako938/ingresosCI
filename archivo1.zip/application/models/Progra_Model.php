<?php
class Progra_Model extends Index_Model{

    public function seleccionar_salida(){

        $this-> default = $this->load->database('default', TRUE);
        $sql=" SELECT ID, USUARIO, NUMEMPLEADO, PR, SP, DEP, SD, PARTIDA 
                FROM usuarios;";

        $query = $this->default->query($sql, array());
        $this->default->close();

        $Out = array();

        foreach ( $query->result_array() as $row )
        {
            $Out[] = array( 
                'id' =>  $row['ID'],
                'vcUsuario' => $row['USUARIO'],
                'iNumEmp'  => $row['NUMEMPLEADO'],
                'iPR' => $row['PR'],
                'iSP' => $row['SP'],
                'iDEP' => $row['DEP'],
                'iSD' => $row['SD'],
                'ipartida' => $row['PARTIDA']  
            );
        }
        return $Out;
    }

    // public function ingresaNumeros(){

    // }

}