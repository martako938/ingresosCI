<div id="appPrograma"> 

    <div class="row">
        <div class="col-1"></div>
        <div class="col-4"><h4>Módulo: Cálculo Código Programático</h4></div>
        <div class="col-7"></div>
    </div>
    </br>


    <ol v-if="viewEntrada === true" class="breadcrumb sinFondo">
            <li class="breadcrumb-item-active" aria-current="page" ><text class="titulo6"><a>Entrada/</a></text></li>
            <li class="breadcrumb-item" aria-current="page" ><text class="titulo6"><a href="#" @click="irSalida()">Salida</a></text></li>
            <li class="breadcrumb-item active" aria-current="page"><text class="titulo6"><a href="<?= base_url('/contacto')?>">Contacto</a></text></li>
    </ol> 


    <ol v-if="viewSalida === true" class="breadcrumb sinFondo">
            <li class="breadcrumb-item"><a href="#"  @click="irEntrada()">Entrada</a></li>
            <li class="breadcrumb-item-active" aria-current="page" ><text class="titulo6"><a> / Salida /</a></text></li>
            <li class="breadcrumb-item active" aria-current="page"><text class="titulo6"><a href="<?= base_url('/contacto')?>">Contacto</a> </text></li>          
    </ol> 
    


    <div class="container mt3 area4 profundidad">
        <br>
        <div v-if="viewEntrada">
            <div class="row">

                <div class="col-3 text-center"></div>
            
                <div class="col-6 text-center">

                    <div class="mb-3">
                        <h5> <b>Entrada</b></h5>
                    </div>

                    <div class="card mb-2 profundidad2">
                        <div class="card-body edge2">

                            <h5> <b>Ingresa números de empleado:</b></h5>                            
                            <br>

                            <form id="ingresarReg" @submit.prevent="ingresarNumeros()">
                                <p class="card-text">
                                    <!-- <input type="text" maxlength="7" id="iNumEmp"  name="iNumEmp" class="form-control form-control-sm edge2" v-model="busqueda" @keyup="procesarBusqueda" placeholder="Num. Trabajador">  -->
                                    <textarea id="vcNums" name="vcNums" rows="4" cols="20" placeholder=""></textarea>
                                </p>

                                <div class="btn-group mb-3">
                                    <button type="button" class="btn butGreen2 btn-sm"  @click="ingresarNumeros()" href="#">Enviar</button>
                                    <button type="button" class="btn btn-outline-warning"  @click="irSalida">Salida</button>
                                </div>
                            </form> 

                        </div>
                    </div>

                </div>

                <div class="col-3 text-center"></div>
            
            </div>
        </div>

        <div v-if="viewSalida">
            <div class="row">
                <div class="col-1 text-center"></div>
                    
                <div class="col-10 text-center">
                    <div class="mb-3">
                        <h5> <b>Salida</b></h5>
                    </div>
                    <!-- Tabla de datos -->
                    <div class="row">
                        <div class="card col-12 profundidad2">
                                </br>
                                <h4>Empleados - Códigos</h4>
                                </br>
                            
                            <div class="table-responsive-md navSupDark profundidad2">
                                <table class="table2 tablaBorde table-bordered" id="miTabla">
                                    <thead class="titulo3" >           
                                        <tr>
                                            <th scope="col" class=" text-center">#</th>
                                            <th scope="col" class=" text-center">Usuario</th>
                                            <th scope="col" class=" text-center">N° Empleado</th>
                                            <th scope="col" class=" text-center">PR</th>
                                            <th scope="col" class=" text-center">SP</th>
                                            <th scope="col" class=" text-center">DEP</th>
                                            <th scope="col" class=" text-center">SD</th>
                                            <th scope="col" class=" text-center">Partida</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <template v-for="(sal, index) in salida" :key="index">     
                                            <tr class="profundidad2">
                                                <td scope="row" class="text-center sizeWidth2">
                                                    <div class="marginsTable">{{index+1}}</div>
                                                </td>
                                                <td scope="row" class="text-center sizeWidth2">
                                                    <div class="marginsTable">{{salida[index].vcUsuario }}</div>
                                                </td>
                                                <td scope="row" class="text-center sizeWidth2">
                                                    <div class="marginsTable">{{salida[index].iNumEmp}}</div>
                                                </td>
                                                <td scope="row" class="text-center sizeWidth2">
                                                    <div class="marginsTable">{{salida[index].iPR}}</div>
                                                </td>
                                                <td scope="row" class="text-center sizeWidth2">
                                                    <div class="marginsTable">{{salida[index].iSP}}</div>
                                                </td>
                                                <td scope="row" class="text-center sizeWidth2">
                                                    <div class="marginsTable">{{salida[index].iDEP}}</div>
                                                </td>
                                                <td scope="row" class="text-center sizeWidth2">
                                                    <div class="marginsTable">{{salida[index].iSD}}</div>
                                                </td>
                                                <td scope="row" class="text-center sizeWidth2">
                                                    <div class="marginsTable">{{salida[index].ipartida}}</div>
                                                </td>
                                            </tr>

                                        </template>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>

                    </br>
                    <div class="btn-group mb-3">
                        <button type="button" class="btn btn-outline-secondary"  @click="irEntrada()">Regresar</button>
                        <button type="button" class="btn butGreen2 btn-sm" @click="exportTableToExcel('miTabla', 'codigos.xls')">Exportar a Excel</button>
                    </div>
                </div>

                <div class="col-1 text-center"></div>
            </div> 
        </div>
        <br>
    </div>

</div>  
