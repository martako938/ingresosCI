<div id="appContacto" > 
    <div v-if="loading"> 
        <span v-html="appLoader"></span></p>
    </div>  

    <ol class="breadcrumb sinFondo">
        <li class="breadcrumb-item"><a href="<?= base_url('./progra')?>">Entrada</a></li>
        <li class="breadcrumb-item active" aria-current="page"><text class="titulo6">Contacto</text></li>
    </ol>

    <div class="card border-dark mb-3 bg-light profundidad" style="max-width: 80rem;">
        <div class="card-header navSup titulo3" style="text-align:center"><strong>Gastos Médicos - Cálculo Código Programático</strong></div>
        <div class="card-body fondoWhite">
        
                <H5 style="text-align:center">
                    <strong><span style="color: #172f57;">Contactos</span></strong>
                </H5>

                </br> 

                <div class="row">
                    <div class="col-sm-2"></div>
                    
                    <div class="col-sm-3">
                        <span style="color: #bd8f16;">
                        <strong>Ing. Carlos Balanzario</h5></strong></span> 
                        <br>Jefe de departamento
                        
                    </div>
                    
                    <div class="col-sm-3">
                        <span style="color: #bd8f16;">
                        <strong>Ing. Angela Galvan</strong></span>
                        <br>Desarrollador 
                    </div>

                    <div class="col-sm-3">
                        <span style="color: #bd8f16;">
                        <strong>Ing. Brayan Cabrera</strong></span>
                        <br>Desarrollador
                        
                    </div>
                    
                    <div class="col-sm-1"></div>
                </div>

                </br>  
                <p class="card-text" style="text-align:center">
                    <i class="bi bi-at" style="color: #bd8f16 ;margin-right: 5px ;"></i>
                        <a href="mailto:padrones@dgp.unam.mx" target="_top">codigos@dgp.unam.mx</a>   
                    <i class="bi bi-telephone-fill" style="color: #bd8f16 ;margin-right: 5px ;"></i><a href="tel:+5215556226124">(55)-5622-6124</a><br/>
                </p>

                <p class="card-text" style="text-align:center">
                    </br>  
                    Hecho en México, Derechos reservados. UNAM, {{ this.anio }}. Esta página no puede ser reproducida. DGPE. Version 1.0.0</br>
                    Última Actualización: {{ this.diaNombre }} {{ this.dia }} de  {{ this.mesNombre }} de {{ this.anio }}.</br>
                    Dirección de Sistemas de la Dirección General de Personal</br></br>
                    <a href="#" data-bs-toggle="modal" data-bs-target="#modalMap" ><u> Dirección: Cto. Centro Cultural 20, Insurgentes Cuicuilco, Coyoacán, Ciudad de México, CDMX C.P., 04510</u></a>
                </p>

        </div>
    </div>

    <hr class="my-4">

    <!-- Modal Map-->
    <div class="modal fade" id="modalMap" tabindex="-1" aria-labelledby="modalMap" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                    <div class="modal-header navSup titulo3">
                        <h1 class="modal-title fs-5" id="mapModalLabel">UNAM Coordinación General de Planeación y Simplificación de la Gestión Institucional</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">

                        <div class="form-group">                             
                            <div class="mapouter">
                                <div class="gmap_canvas">
                                    <iframe src="https://maps.google.com/maps?q=UNAM%20Coordinaci%C3%B3n%20General%20de%20Planeaci%C3%B3n%20y%20Simplificaci%C3%B3n%20de%20la%20Gesti%C3%B3n%20Institucional&amp;t=&amp;z=17&amp;ie=UTF8&amp;iwloc=&amp;output=embed" width="765" height="650" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
                                    </iframe>
                                </div>
                            </div>
                        </div>    

                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn butBlue sizeWidth2" data-bs-dismiss="modal">Cerrar</button>
                    </div>
                </div>
        </div>
    </div>

</div>              <!-- Fin appContacto -->

