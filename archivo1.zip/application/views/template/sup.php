

<div id="content">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark navSup">
            <div class="container">
                <div class="navbar-header navbar-left">
                    <a href="https://www.unam.mx/" class="hidden-xs navbar-brand"><img alt="UNAM" style="width: 95px" src="<?= base_url('/images/logoUNAM2.png')?>"></a>   
                </div>
                <div class="navbar-header navbar-center logo text-center">
                    <span class="titulo">Gastos Médicos Mayores</span><br>
                    
                </div>
                <div class="navbar-header navbar-right">
                    <a href="https://www.personal.unam.mx" class="hidden-xs navbar-brand"><img alt="DGPe" style="width: 90px"  src="<?= base_url('/images/LogotipoDGPE_blanco.png')?>"></a>   
                </div>
            </div>
        </nav>

        <nav class="navbar navbar-expand-md navbar-light bg-light navDelgada2 profundidad2">
            <a class="navbar-brand titulo6" title="" href="<?= base_url('/elecciones')?>"> &nbsp;  </a>                         
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarColor01">
                <ul class="navbar-nav mr-auto ">

                    <li class="nav-item"> 
                        <a class="nav-link titulo6" href="<?= base_url('/contacto')?>" >&nbsp;&nbsp;&nbsp;Contacto </a>  
                    </li>

                </ul>
                <form class="position-absolute top-50 end-0 translate-middle-y">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item">
                            <a class="nav-link titulo6" href="https://casiopea.personalds.unam.mx/sa/UI/Logout">&nbsp;&nbsp;&nbsp;Cerrar Sesión</a>
                        </li>
                    </ul>
                </form>
            </div>
        </nav>

</div>

<body class="conFondo">
    <div class="container">
        </br>
        <!-- Content -->