axios.defaults.timeout = 10000;
const appPrograma = Vue.createApp({
    data(){
        return{
                loading: true,
                appLoader: '<div class="preloader" align="center"><svg width="200" height="200" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid" class="lds-ripple" style="background:0 0"><circle cx="50" cy="50" r="4.719" fill="none" stroke="#1d3f72" stroke-width="2"><animate attributeName="r" calcMode="spline" values="0;40" keyTimes="0;1" dur="3" keySplines="0 0.2 0.8 1" begin="-1.5s" repeatCount="indefinite"/><animate attributeName="opacity" calcMode="spline" values="1;0" keyTimes="0;1" dur="3" keySplines="0.2 0 0.8 1" begin="-1.5s" repeatCount="indefinite"/></circle><circle cx="50" cy="50" r="27.591" fill="none" stroke="#5699d2" stroke-width="2"><animate attributeName="r" calcMode="spline" values="0;40" keyTimes="0;1" dur="3" keySplines="0 0.2 0.8 1" begin="0s" repeatCount="indefinite"/><animate attributeName="opacity" calcMode="spline" values="1;0" keyTimes="0;1" dur="3" keySplines="0.2 0 0.8 1" begin="0s" repeatCount="indefinite"/></circle></svg></div>',
                viewEntrada: true, viewSalida: false,
                salida: [], numerosEmp: '', numerosEmpArr: [], numerosEmpSep : '',
                msg_res:'\n* Se realizó la solicitud y el servidor respondió con un código de \nestado que cae fuera del rango de 2xx\nerr.res.status:', res2: '\nerr.res.headers: ', res3: '\n error.response.data: ',
                msg_req:'\n* La solicitud se realizó pero no se recibió respuesta, `error.request` es \nuna instancia de XMLHttpRequest en el navegador y una instancia de http.ClientRequest en Node.js \nerr.req: ', 
                msg_err:'\n* Algo sucedió al configurar la solicitud y provocó un error\nError: ',
                msg_err2: 'error.config: '
        }
    },
    created(){
        this.traerSalida()
    },
    methods: {
        irEntrada(){
            this.viewEntrada = true
            this.viewSalida = false
        },
        irSalida(){
            this.viewEntrada = false
            this.viewSalida = true
        },
        ingresarNumeros(){
                const form = document.getElementById('ingresarReg')
                let url = base + 'progra/ingresaNum'
                var datosForm = new FormData(form);

                axios.post(url, datosForm).then(res => {
                    this.numerosEmp = res.data.vcNums
                    console.log( 'Datos int',this.numerosEmp)
                    this.numerosEmpArr = this.numerosEmp.split(`\r\n`)               //Separando numeros de empleado en arreglo
                    console.log('numArr',this.numerosEmpArr)
                    for(i=0;i<this.numerosEmpArr.length;i++){
                        this.numerosEmpSep += this.numerosEmpArr[i]
                        if(i!=this.numerosEmpArr.length-1){
                            this.numerosEmpSep += ','
                        }
                    }
                    console.log('nums Sep',this.numerosEmpSep)
                }).catch((error)=>{    })
        },
        exportTableToExcel(tableID, filename) {
            if (!filename)
                filename = 'excel_data.xls';
                let dataType = 'application/vnd.ms-excel';
                let tableSelect = document.getElementById(tableID);
                let tableHTML = tableSelect.outerHTML;
                let blob = new Blob([tableHTML], {type: dataType});
            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                window.navigator.msSaveOrOpenBlob(blob, filename);
            } else {
                let a = document.createElement("a");
                document.body.appendChild(a);
                a.style = "display: none";
                let csvUrl = URL.createObjectURL(blob);
                a.href = csvUrl;
                a.download = filename;
                a.click();
                URL.revokeObjectURL(a.href)
                a.remove();
            }
        },
        traerSalida(){
            this.loading = true
            var url = base+'progra/traeSal'
            axios.get(url)
                .then(res =>{
                    this.salida = res.data
                    //console.log('salida: ', this.salida);
                    this.loading = false
            })
        },
        datosMensaje(tipo, cab, msg){
            if(tipo== 'exito'){         var ico=    '<h1><i class="bi bi-check-circle-fill" style="color: #17816a ;padding px-5 ;"></i></h1><h4><b>'        }
            else if(tipo== 'error'){    var ico=   '<h1><i class="bi bi-x-octagon" style="color: #d63d0b ;padding px-5 ;"></i></h1><h4><b>¡Error!</b></h4>' }
            ico+=   cab;    ico+=   '</b></h4>';    ico+=   msg;    return ico;
        },
        msjAlertTimeOut(title){
            var ico = this.datosMensaje('error','¡Oops!',' ... El servidor ha tardado mucho en responder, intente de nuevo  más tarde.')
            Swal.fire({
                title: title, 
                html: ico,
                background: `rgba(243, 247, 248)`,
                confirmButtonText: 'OK',  
                buttonsStyling: false,
                customClass: {
                    confirmButton: "btn butBlue1 sizeWidth2",
                    title: 'navSup titulo3'
                }
            }).then((result) => { 
                if (result.isConfirmed) {   }
            })
        }
    },
    computed:{
    },
})
.mount('#appPrograma');